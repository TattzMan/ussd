package com.victorycollege.ussd;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/ussd")
@CrossOrigin(origins = "*") // Allows any client to make requests
public class UssdController {

    // Simulates session data storage
    private final Map<String, String> sessionData = new HashMap<>();

    @PostMapping("/request")
    public ResponseEntity<Map<String, String>> handleUssdRequest(@RequestBody Map<String, String> request) {
        String sessionId = request.get("sessionId");
        String ussdCode = request.get("ussdCode");
        String userInput = request.get("userInput");

        String responseMessage;
        String sessionStatus = "CONTINUE";

        // Simple USSD logic based on the code and user input
        if (ussdCode.startsWith("*123#")) {
            // Main menu
            if (userInput == null || userInput.isEmpty()) {
                responseMessage = "Welcome to the LMS USSD System!\n1. View My Courses\n2. View My Grades\n0. Exit";
                sessionData.put(sessionId, "main_menu");
            } else if ("main_menu".equals(sessionData.get(sessionId))) {
                switch (userInput) {
                    case "1":
                        // In a real system, you would query the database here
                        responseMessage = "Your enrolled courses:\n- Math 101\n- History 201\n0. Back";
                        sessionData.put(sessionId, "view_courses");
                        break;
                    case "2":
                        // In a real system, you would query the database here
                        responseMessage = "Your grades:\n- Math 101: A\n- History 201: B+\n0. Back";
                        sessionStatus = "END";
                        sessionData.remove(sessionId);
                        break;
                    case "0":
                        responseMessage = "Thank you for using our service. Goodbye!";
                        sessionStatus = "END";
                        sessionData.remove(sessionId);
                        break;
                    default:
                        responseMessage = "Invalid input. Please try again.\n1. View My Courses\n2. View My Grades\n0. Exit";
                        sessionData.put(sessionId, "main_menu");
                        break;
                }
            } else if ("view_courses".equals(sessionData.get(sessionId))) {
                switch (userInput) {
                    case "0":
                        responseMessage = "Welcome to the LMS USSD System!\n1. View My Courses\n2. View My Grades\n0. Exit";
                        sessionData.put(sessionId, "main_menu");
                        break;
                    default:
                        responseMessage = "Invalid input. Please try again.\n0. Back";
                        sessionData.put(sessionId, "view_courses");
                        break;
                }
            } else {
                responseMessage = "Invalid request.";
                sessionStatus = "END";
                sessionData.remove(sessionId);
            }
        } else {
            responseMessage = "Invalid USSD code.";
            sessionStatus = "END";
        }

        Map<String, String> response = new HashMap<>();
        response.put("message", responseMessage);
        response.put("status", sessionStatus);
        return ResponseEntity.ok(response);
    }
}
