package com.yourcompany.ussd;

import com.fasterxml.jackson.databind.ObjectMapper;
import okhttp3.*;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

public class Main {

    private static final OkHttpClient client = new OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .writeTimeout(10, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .build();
    private static final String API_URL = "http://localhost:8080/ussd/request";
    private static final ObjectMapper objectMapper = new ObjectMapper();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String sessionId = UUID.randomUUID().toString();
        String currentUssdCode = "";
        boolean isSessionActive = false;

        System.out.println("Welcome to the Java USSD Console.");
        System.out.println("Enter a USSD code (e.g., *123#) to begin.");

        while (true) {
            System.out.print("> ");
            String userInput = scanner.nextLine().trim();

            if ("exit".equalsIgnoreCase(userInput)) {
                System.out.println("Goodbye!");
                break;
            }

            try {
                // If a session is not active, the input is the initial USSD code
                if (!isSessionActive) {
                    if (userInput.endsWith("#")) {
                        currentUssdCode = userInput;
                        System.out.println("Dialing " + currentUssdCode + "...");
                        Map<String, String> response = makeUssdRequest(sessionId, currentUssdCode, null);
                        if (response != null) {
                            displayResponse(response);
                            isSessionActive = "CONTINUE".equals(response.get("status"));
                        }
                    } else {
                        System.err.println("Invalid USSD code. Must end with '#'.");
                    }
                } else {
                    // If a session is active, the input is a menu option
                    Map<String, String> response = makeUssdRequest(sessionId, currentUssdCode, userInput);
                    if (response != null) {
                        displayResponse(response);
                        isSessionActive = "CONTINUE".equals(response.get("status"));
                        if (!isSessionActive) {
                            System.out.println("\nSession ended. Enter a new USSD code to begin again.");
                            currentUssdCode = "";
                        }
                    }
                }
            } catch (IOException e) {
                System.err.println("Communication error: " + e.getMessage());
                isSessionActive = false;
                currentUssdCode = "";
            }
        }
        scanner.close();
    }

    private static Map<String, String> makeUssdRequest(String sessionId, String ussdCode, String userInput) throws IOException {
        Map<String, String> payload = new HashMap<>();
        payload.put("sessionId", sessionId);
        payload.put("ussdCode", ussdCode);
        payload.put("userInput", userInput);

        RequestBody body = RequestBody.create(
                objectMapper.writeValueAsString(payload),
                MediaType.parse("application/json; charset=utf-8")
        );

        Request request = new Request.Builder()
                .url(API_URL)
                .post(body)
                .build();

        // Exponential backoff retry logic
        final int maxRetries = 5;
        int attempt = 0;
        long delay = 1000;

        while (attempt < maxRetries) {
            try (Response response = client.newCall(request).execute()) {
                if (response.isSuccessful() && response.body() != null) {
                    return objectMapper.readValue(response.body().string(), Map.class);
                } else {
                    System.err.println("HTTP error: " + response.code() + " " + response.message());
                    throw new IOException("Server returned an error.");
                }
            } catch (IOException e) {
                attempt++;
                if (attempt < maxRetries) {
                    System.err.println("Request failed, retrying in " + delay + "ms...");
                    try {
                        Thread.sleep(delay);
                    } catch (InterruptedException ie) {
                        Thread.currentThread().interrupt();
                    }
                    delay *= 2; // Exponential backoff
                } else {
                    throw e; // Re-throw the exception after max retries
                }
            }
        }
        return null; // Should not be reached
    }

    private static void displayResponse(Map<String, String> response) {
        String message = response.get("message");
        System.out.println("--- USSD Response ---");
        System.out.println(message);
        System.out.println("---------------------");
    }
}
